package com.example.kafka.Consumer3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Consumer3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
